var debug = true;

if(debug) console.log("SafecardFixQuercus");

var images = document.getElementsByTagName('img');
for (var i = 0; i < images.length; i++) {
  images[i].src = images[i].src.replace(/^http:\/\/10\.\d{1,3}\.\d{1,3}\.\d{1,3}/g, "http://localhost");
}
